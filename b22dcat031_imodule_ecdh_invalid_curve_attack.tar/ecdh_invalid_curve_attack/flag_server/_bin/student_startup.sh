#!/bin/bash

# Kiểm tra nếu đang chạy dưới quyền user (không phải root)
id | grep root > /dev/null
if [[ $? -ne 0 ]]; then
    # Chạy server khi vào terminal
    python3 /home/ubuntu/flag_server.py
fi

