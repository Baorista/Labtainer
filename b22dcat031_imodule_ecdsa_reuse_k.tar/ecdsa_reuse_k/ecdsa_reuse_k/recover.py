try:
    print(f"Recovered k = {k}")
    print(f"Recovered d = {d}")
    print("Decrypted secret:", plaintext.decode())

except Exception as e:
    print("Recover failed:", e)
