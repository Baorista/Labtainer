from hashlib import sha1, sha256
from random import randint
from ecdsa import SigningKey, NIST192p
from Crypto.Cipher import AES
m1file = "/home/ubuntu/m1.txt"
m2file = "/home/ubuntu/m2.txt"
with open(m1file, "rb") as f:
    msg1 = f.read()
with open(m2file, "rb") as f:
    msg2 = f.read()


d = 6743529130774090927928101169617481154782309
sk = SigningKey.from_secret_exponent(d,curve = NIST192p)
vk = sk.verifying_key
with open("/home/ubuntu/public_key.pem", "wb") as f:
    f.write(vk.to_pem())

another_d = ANOTHER_DI
another_sk = SigningKey.from_secret_exponent(another_d, curve = NIST192p)
another_vk = another_sk.verifying_key
with open("/home/ubuntu/another_public_key.pem","wb") as f:
    f.write(another_vk.to_pem())
k = THESAMEKEY
sig1 = sk.sign(msg1, k=k, hashfunc=sha1)
sig2 = sk.sign(msg2, k=k, hashfunc=sha1)

with open("/home/ubuntu/sig1.txt", "wb") as f:
    f.write(sig1)
with open("/home/ubuntu/sig2.txt", "wb") as f:
    f.write(sig2)
secret_message = b"D0_Y4_KN0W_ECC_!S_FUN"

key = sha256(str(d+another_d).encode()).digest()[:16]

padded_msg = secret_message + b' ' * (16 - len(secret_message) % 16)
cipher = AES.new(key, AES.MODE_ECB)
ciphertext = cipher.encrypt(padded_msg)

with open("/home/ubuntu/secret.ct", "wb") as f:
    f.write(ciphertext)
