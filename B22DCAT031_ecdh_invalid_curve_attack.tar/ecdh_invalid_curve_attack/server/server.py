import socket
import pickle
from ecdsa.ecdsa import generator_128r1, curve_128r1
from Crypto.Util.number import long_to_bytes
from Crypto.Util.Padding import pad
from Crypto.Cipher import AES
import random
import traceback

curve = curve_128r1
G = generator_128r1
n = G.order()
p = curve.p()
a = curve.a()
b = curve.b()
private_key = random.randrange(n)

class FakePoint:
    def __init__(self, x, y, a, b, p):
        self.x_val = int(x)
        self.y_val = int(y)
        self.a = a
        self.b = b
        self.p = p

    def x(self):
        return self.x_val

    def y(self):
        return self.y_val

    def __rmul__(self, scalar):
        from sage.all import EllipticCurve, GF
        try:
            E = EllipticCurve(GF(self.p), [self.a, self.b])
            P = E(self.x_val, self.y_val)  # tạo điểm trên curve giả
            return scalar * P
        except Exception as e:
            raise ValueError("Cannot multiply point — invalid input:", e)


def encrypt_data(shared_point, message):
    if shared_point.is_zero():
        x, y = 0, 0
    else:
        x, y = shared_point.xy()
    key = long_to_bytes(int(x)).rjust(16, b"\x00")
    iv = long_to_bytes(int(y)).rjust(16, b"\x00")
    cipher = AES.new(key, AES.MODE_CBC, iv)
    message = pad(message.encode(), 16)
    return cipher.encrypt(message)
def send_key_to_flag_server(Q, G, curve_params):
    import socket, pickle
    payload = {
        "Q": (int(Q.x()), int(Q.y())),
        "G": (int(G.x()), int(G.y())),
        "curve": curve_params
    }
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as fs:
        fs.connect(("10.10.10.30", 8888))
        fs.send(pickle.dumps(payload))
def ECDH(A):
    shared_point = private_key * A
    message = "Inconceivable!"
    return encrypt_data(shared_point, message)

def send_curve_params(conn):
    params = {
        "p": p,
        "a": a,
        "b": b,
        "G": (int(G.x()), int(G.y()))
    }
    conn.send(pickle.dumps(params))

def handle_client(conn):
    send_curve_params(conn)
    while True:
        try:
            data = conn.recv(4096)
            if not data:
                print("[-] Client close the connection.")
                break
            x, y, b = pickle.loads(data)
            A = FakePoint(x, y,a,b, p)
            ciphertext = ECDH(A)
            conn.send(ciphertext)
            print("[+] Send ciphertext for public key:",(A.x(), A.y()))
        except Exception as e:
            print("[-] Error when handle the public key:", e)
            traceback.print_exc()
            break
    conn.close()

def main():
    host = "0.0.0.0"
    port = 9999
    Q = private_key * G
    curve_params = {"p": p, "a": a, "b": b}
    send_key_to_flag_server(Q, G, curve_params)
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((host, port))
        while True:
            s.listen(1)
            print(f"[+] Listening on port {port}...")
            conn, addr = s.accept()
            print(f"[+] Connection from {addr}")
            handle_client(conn)

if __name__ == "__main__":
    main()

