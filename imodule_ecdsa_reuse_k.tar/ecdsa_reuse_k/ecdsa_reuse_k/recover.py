# Viết mã khôi phục k từ 2 chữ ký tại đây
# Nếu thành công:
# with open("recover_output.txt", "w") as f:
#     f.write("Success")
# Nếu thất bại:
# with open("recover_output.txt", "w") as f:
#     f.write("Failed")
