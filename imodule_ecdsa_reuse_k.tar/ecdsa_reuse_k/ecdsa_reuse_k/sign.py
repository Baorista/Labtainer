from hashlib import sha1
from random import randint
from ecdsa import SigningKey, NIST192p

#m1file = "m1.txt"
#m2file = "m2.txt"
# Đọc hai thông điệp từ file
with open(m1file, "rb") as f:
    msg1 = f.read()
with open(m2file, "rb") as f:
    msg2 = f.read()

# Sinh private và public key
sk = SigningKey.generate(curve=NIST192p)
vk = sk.verifying_key

# Lưu public key
with open("public_key.pem", "wb") as f:
    f.write(vk.to_pem())

# Ký hai thông điệp với cùng k
k = THESAMEKEY
sig1 = sk.sign(msg1, k=k, hashfunc=sha1)
sig2 = sk.sign(msg2, k=k, hashfunc=sha1)

with open("sig1.txt", "wb") as f:
    f.write(sig1)
with open("sig2.txt", "wb") as f:
    f.write(sig2)
with open("status.txt", "w") as f:
    f.write("SIGNED")

print("Đã ký xong 2 thông điệp với cùng k.")
