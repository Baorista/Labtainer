from ecdsa.ellipticcurve import CurveFp, Point
import math

# Tham số đường cong
p = 3056896859
a = 957649667
b = 1634195995
curve = CurveFp(p, a, b)

# Điểm sinh G và bậc n
G = Point(curve, 2972881160, 983578779)
n = 3056945892

# Đọc public key từ file
with open("/home/ubuntu/another_public_key.pem") as f:
    x_str, y_str = f.read().strip().split(",")
    Q = Point(curve, int(x_str), int(y_str))

print("another_d =", another_d)
