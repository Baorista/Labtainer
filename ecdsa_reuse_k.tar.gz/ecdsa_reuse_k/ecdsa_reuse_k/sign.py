from hashlib import sha1
from random import randint
from ecdsa import SigningKey, NIST192p

m1file = "/home/ubuntu/m1.txt"
m2file = "/home/ubuntu/m2.txt"
# Đọc hai thông điệp từ file
with open(m1file, "rb") as f:
    msg1 = f.read()
with open(m2file, "rb") as f:
    msg2 = f.read()


# Sinh private và public key
d = THESECRET
sk = SigningKey.from_secret_exponent(d,curve = NIST192p)
vk = sk.verifying_key
with open("/home/ubuntu/key.txt","w") as f:
    f.write(str(d))
# Lưu public key
with open("/home/ubuntu/public_key.pem", "wb") as f:
    f.write(vk.to_pem())

# Ký hai thông điệp với cùng k
k = THESAMEKEY
sig1 = sk.sign(msg1, k=k, hashfunc=sha1)
sig2 = sk.sign(msg2, k=k, hashfunc=sha1)

with open("/home/ubuntu/sig1.txt", "wb") as f:
    f.write(sig1)
with open("/home/ubuntu/sig2.txt", "wb") as f:
    f.write(sig2)

print("Đã ký xong 2 thông điệp với cùng k.")
