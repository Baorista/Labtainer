from ecdsa import SigningKey, SECP128r1
from ecdsa.util import sigdecode_string
import socket, pickle

sk = SigningKey.from_secret_exponent(d, curve=SECP128r1)

message = b"give me the flag"
signature = sk.sign(message)

r, s = sigdecode_string(signature, sk.curve.order)

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
    sock.connect(("10.10.10.30", 8888))
    payload = {
        "msg": message,
        "sig": (r, s)
    }
    sock.send(pickle.dumps(payload))
    flag = sock.recv(1024)
    print("Received_flag:", flag.decode())

