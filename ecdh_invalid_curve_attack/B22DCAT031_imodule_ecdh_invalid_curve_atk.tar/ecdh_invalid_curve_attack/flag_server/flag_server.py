import socket, pickle
from ecdsa import VerifyingKey, ellipticcurve, curves
from ecdsa.util import sigdecode_string

def receive_initial_key(conn):
    data = conn.recv(4096)
    payload = pickle.loads(data)

    Qx, Qy = payload["Q"]
    Gx, Gy = payload["G"]
    curve_params = payload["curve"]

    curve = curves.SECP128r1

    G = ellipticcurve.Point(curve.curve, Gx, Gy)
    Q = ellipticcurve.Point(curve.curve, Qx, Qy)

    vk = VerifyingKey.from_public_point(Q, curve=curve)
    print("[+] Nhận public key thành công.")
    return vk

def handle_attacker(conn, vk):
    data = conn.recv(4096)
    payload = pickle.loads(data)
    msg = payload["msg"]
    r, s = payload["sig"]

    print("[*] Đang xác minh chữ ký cho thông điệp:", msg.decode())

    sig_bytes = r.to_bytes(16, 'big') + s.to_bytes(16, 'big')

    try:
        if vk.verify(sig_bytes, msg, sigdecode=sigdecode_string):
            conn.send(b"FLAG{you_forged_it_successfully}")
        else:
            conn.send(b"FLAG{Stub!d}")
    except Exception as e:
        conn.send(b"FLAG{Stub!d}")
        print("[-] Lỗi xác minh:", e)

def main():
    print("[*] Flag server đang chạy...")
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("0.0.0.0", 8888))
        s.listen(2)

        conn1, _ = s.accept()
        vk = receive_initial_key(conn1)
        conn1.close()

        print("[*] Chờ attacker gửi chữ ký...")
        while True:
            try:
                conn2, _ = s.accept()
                handle_attacker(conn2, vk)
                conn2.close()
            except:
                continue
if __name__ == "__main__":
    main()

