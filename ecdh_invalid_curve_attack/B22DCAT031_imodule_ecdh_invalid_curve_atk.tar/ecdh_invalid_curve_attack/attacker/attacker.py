import socket
import pickle
from ecdsa.ecdsa import curve_128r1
from Crypto.Util.number import long_to_bytes
from Crypto.Util.Padding import pad, unpad
from Crypto.Cipher import AES
from sage.all import EllipticCurve, GF, crt

def decrypt_data(shared_point, ciphertext):
    pass
def brute_force_encrypted_message(A, ciphertext, max_order):
    pass
def find_curves_with_small_subgroup(p, a, max_order):
    pass
    #            yield (f,P,b)

def main(host="<server_ip>", port="server_port"):
    subsolutions = []
    subgroup = []
    max_order = 10000
    upto = 1

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        


    s.connect((host, port))

    data = s.recv(4096)
    params = pickle.loads(data)
    p = params['p']
    a = params['a']
    b = params['b']
    Gx, Gy = params['G']
    E = EllipticCurve(GF(p), [a, b])
    G = E(Gx, Gy)
    n = G.order()
    print(f"    p = {p}")
    print(f"    a = {a}")
    print(f"    G = ({Gx}, {Gy})")

    for order, A,b in find_curves_with_small_subgroup(p,a,max_order):
        upto *= order
        print("Found point with order", order, "so now can find keys of size up to", upto)
        x, y  = A.xy()
        s.send(pickle.dumps((int(x), int(y),int(b))))

        ciphertext = s.recv(1024)
        print(f"[+] Received ciphertest for order {order}: {ciphertext.hex()}")

        key_mod_order = brute_force_encrypted_message(A, ciphertext, max_order)
        subsolutions.append(key_mod_order)
        subgroup.append(order)

        if upto >= n:
            break
    print("Found enough values! Running CRT...")
    found_key = crt(subsolutions, subgroup)
    print("Found private key", found_key)
    s.close()

if __name__ == "__main__":
    main()

